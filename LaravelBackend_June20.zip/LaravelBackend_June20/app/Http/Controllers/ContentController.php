<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Contents;
use App\Models\Products;

class ContentController extends Controller
{
    public function listContent()
    {
        $products = Products::all();
        return view('contents.listContent',compact('products'));
    }
}
