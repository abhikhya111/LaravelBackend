<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\SubCategoryController;
use App\Http\Controllers\ProductController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
// Route::resource('categories', CategoryController::class);
// Route::get('/categories',[CategoryController::class, 'index'])->name('categories');
// Route::get('/dashboard',[CategoryController::class, 'dashboard'])->name('dashboard');
// Route::get('/listCategories',[CategoryController::class, 'listCategories'])->name('listCategories');
// Route::get('/api/getCategories',[CategoryController::class, 'getCategories'])->name('getCategories');
// Route::get('/api/getSubCategories/{id}',[SubCategoryController::class, 'getSubCategories'])->name('getSubCategories');
// Route::get('/api/getProducts/{id}', [ProductController::class, 'getProducts'])->name('getProducts');
// Route::get('/api/listCategory',[CategoryController::class, 'listCategory']);