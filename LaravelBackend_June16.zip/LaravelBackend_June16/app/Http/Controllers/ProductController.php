<?php

namespace App\Http\Controllers;
use App\Models\Products;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class ProductController extends Controller
{
    public function getProducts($id)
    {

        
        $subcat = DB::table('products')->where('subcategory_id', $id)->get();
        return $subcat;


    }
}


