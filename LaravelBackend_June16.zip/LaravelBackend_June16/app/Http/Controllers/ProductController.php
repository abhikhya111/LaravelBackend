<?php

namespace App\Http\Controllers;
use App\Models\Products;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class ProductController extends Controller
{
    public function listProduct()
    {
        $products = Products::all();
        return view('products.listProduct',compact('products'));
    }

    public function createProduct()
    {
        return view('products.createProduct');
    }

    public function editProduct($id)
    {
        return $id;

    }

    public function storeProduct(Request $request) 
    
    {
        return $request;
    }
}


