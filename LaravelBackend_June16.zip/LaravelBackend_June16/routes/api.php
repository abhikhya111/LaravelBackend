<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\SubCategoryController;
use App\Http\Controllers\ProductController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
Route::get('/listCategory',[CategoryController::class, 'listCategory']);
Route::get('/createCategory',[CategoryController::class, 'createCategory'])->name('createCategory');
Route::post('/storeCategory',[CategoryController::class, 'storeCategory'])->name('storeCategory');
Route::get('/editCategory/{id}',[CategoryController::class,'editCategory'])->name('editCategory');
Route::post('/updateCategory/{id}',[CategoryController::class,'updateCategory'])->name('updateCategory');

Route::get('/listSubCategory',[SubCategoryController::class,'listSubCategory'])->name('listSubCategory');
Route::get('/createSubCategory',[SubCategoryController::class, 'createSubCategory'])->name('createSubCategory');
Route::post('/storeSubCategory',[SubCategoryController::class, 'storeSubCategory'])->name('storeSubCategory');
Route::get('/editSubCategory/{id}',[SubCategoryController::class,'editSubCategory'])->name('editSubCategory');
Route::post('/updateSubCategory/{id}',[SubCategoryController::class,'updateSubCategory'])->name('updateSubCategory');

Route::get('/listProduct',[ProductController::class,'listProduct'])->name('listProduct');
Route::get('/createProduct',[ProductController::class, 'createProduct'])->name('createProduct');
Route::post('/product',[ProductController::class, 'storeProduct'])->name('storeProduct');
Route::get('/product/{id}',[ProductController::class,'editProduct'])->name('editProduct');
Route::post('/product/{id}',[ProductController::class,'updateProduct'])->name('updateProduct');