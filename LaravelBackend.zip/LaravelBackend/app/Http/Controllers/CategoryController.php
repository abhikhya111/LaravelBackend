<?php

namespace App\Http\Controllers;
use App\Models\Category;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function dashboard()
    {
        return view('categories.index');
    }
    public function listCategories()
    {
        $data['categories'] = Category::all();
        return view('categories.listCategory',$data);
    }

    public function create()
    {
    return view('categories.create');
    }

    public function store(Request $request)
    {
        $category = new Category;
        $category->name = $request->name;
        $category->slug = $request->slug;
        $category->save();
        return redirect()->route('categories.index')
        ->with('success','Category has been created successfully.');
    }

    public function edit(Category $category)
    {
        return view('categories.edit',compact('category'));
    }

    public function update(Request $request, $id)
    {
        $category = Category::find($id);
        $category->name = $request->name;
        $category->slug = $request->slug;
        $category->save();
        return redirect()->route('categories.index')
        ->with('success','Category Has Been updated successfully');
    }

    public function destroy(Category $category)
    {
        $category->delete();
        return redirect()->route('categories.index')
        ->with('success','Category has been deleted successfully');
    }

    public function getCategories()
    {
        $category = Category::all();
        return $category;
    }

    public function getSubCategories($id)
    {
        return $id;

    }
}
