<?php

namespace App\Http\Controllers;
use App\Models\SubCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SubCategoryController extends Controller
{
    public function getSubCategories($id)
    {

        // $sub = SubCategory::where($id,'1')->get();
        // return $sub;
        $subcat = DB::table('sub_categories')->where('categoryId', $id)->get();
        return $subcat;


    }
}
