<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\SubCategory;
use App;
class SubCategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        SubCategory::create([
            'categoryId' => '1',
            'name' => 'Xtra Power Professional',
            'desc' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam',
            'slug' => 'xtraPower',
            'metaTitle' => 'xtraPower',
            'metaDesc' => 'xtraPower',
            'metaKeyword' => 'xtraPower',
            'image' => 'https://xtrapowertools.com/wp-content/uploads/2021/10/power-tool-011-600x600.jpg'
        ]);

        SubCategory::create([
            'categoryId' => '1',
            'name' => 'Xtra Power Gold',
            'desc' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam',
            'slug' => 'xtraPower',
            'metaTitle' => 'xtraPower',
            'metaDesc' => 'xtraPower',
            'metaKeyword' => 'xtraPower',
            'image' => 'https://xtrapowertools.com/wp-content/uploads/2021/10/power-tool-011-600x600.jpg'
        ]);

        SubCategory::create([
            'categoryId' => '1',
            'name' => 'Xtra Power Heavy Duty',
            'desc' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam',
            'slug' => 'xtraPower',
            'metaTitle' => 'xtraPower',
            'metaDesc' => 'xtraPower',
            'metaKeyword' => 'xtraPower',
            'image' => 'https://xtrapowertools.com/wp-content/uploads/2021/10/power-tool-011-600x600.jpg'
        ]);

        SubCategory::create([
            'categoryId' => '1',
            'name' => 'HI-Max Power Tools',
            'desc' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam',
            'slug' => 'xtraPower',
            'metaTitle' => 'xtraPower',
            'metaDesc' => 'xtraPower',
            'metaKeyword' => 'xtraPower',
            'image' => 'https://xtrapowertools.com/wp-content/uploads/2021/10/power-tool-011-600x600.jpg'
        ]);
        
       
    }
}
